package com.example.animationcapacity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
